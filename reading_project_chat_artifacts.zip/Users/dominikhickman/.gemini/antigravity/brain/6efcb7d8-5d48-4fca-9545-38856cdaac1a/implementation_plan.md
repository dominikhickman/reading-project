# Teacher Dashboard & Difficulty Implementations

This plan outlines the steps to add difficulty scaling to the Bee and Flower game, correctly isolate students by their teacher, and allow teachers to add new students dynamically.

## User Review Required

> [!IMPORTANT]
> **Database Modification Needed**: Since we are adding a difficulty setting, you will need to run a quick SQL command in your Supabase Dashboard to add the new `difficulty` column to the `students` table. 
> 
> Please let me know once you approve this plan, and I'll generate the SQL for you to run!

## Proposed Changes

### Database Migration
#### [NEW] [supabase/migrations/003_add_difficulty.sql](file:///Users/dominikhickman/i400-Folder/Reading-Project/supabase/migrations/003_add_difficulty.sql)
- Contains the SQL to add a `difficulty` column (defaulting to 'Medium') to the `students` table.

---

### Global Context
#### [MODIFY] [src/context/AppContext.jsx](file:///Users/dominikhickman/i400-Folder/Reading-Project/src/context/AppContext.jsx)
- Update `fetchClassData`: Pass the logged-in teacher's actual Supabase Auth `user.id` to correctly load ONLY their students (`.eq('teacher_id', teacherId)`).
- Add new methods: `updateStudentDifficulty` to handle difficulty saving, and `addStudent` to handle creating a new student linked to the teacher.

---

### Teacher Tools
#### [MODIFY] [src/pages/TeacherDashboard.jsx](file:///Users/dominikhickman/i400-Folder/Reading-Project/src/pages/TeacherDashboard.jsx)
- **Adjust Difficulty**: Replace the static "Adjust Difficulty" button with a functional dropdown (`<select>`) that patches the student's difficulty (Easy, Medium, Hard).
- **Add Student**: Add an inline form/button combination at the top or bottom of the dashboard allowing the teacher to type a new student's name and create them in the system.

---

### Game Logic
#### [MODIFY] [src/pages/games/BeeFlowerGame.jsx](file:///Users/dominikhickman/i400-Folder/Reading-Project/src/pages/games/BeeFlowerGame.jsx)
- Read the current logged-in student's `difficulty` level.
- Scale the game dynamically:
  - **Easy**: 3 words to match at a time.
  - **Medium**: 6 words to match (current default).
  - **Hard**: 9 words to match.

## Open Questions

- Does the teacher need the ability to delete a student, or is just checking and adding enough for now?
- Would you like the "Add Student" to be a pop-up modal or just an inline text field at the top of the dashboard? (I plan to use an inline form for simplicity unless you prefer a modal).

## Verification Plan

### Manual Verification
- A Teacher logs in, verifying they only see their own students.
- Adding a student updates the list immediately.
- Changing a student to "Easy", logging in as that student, and verifying the game only gives 3 bees/flowers instead of 6.
