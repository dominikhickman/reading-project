# Unit Test: Buddy Level Calculator

**Test File:** `src/utils/pointCalculation.test.js`

```javascript
import { expect, test } from 'vitest';

export function calculateLevel(points) {
  if (points > 300) return 3;
  if (points > 100) return 2;
  return 1;
}

test('calculateLevel assigns the correct buddy level based on points', () => {
  // We feed it fake point numbers and ensure the level output is true!
  expect(calculateLevel(50)).toBe(1);  // Student with 50 points stays level 1
  expect(calculateLevel(150)).toBe(2); // Student hits 150 points, jumps to level 2
  expect(calculateLevel(500)).toBe(3); // Student clears 300 points, reaches max level!
});
```

---

## Output Status: PASS ✅

Below is the successful terminal test run confirming the logic works perfectly!

```shell
> reading-project@0.0.0 test
> vitest run

 RUN  v4.1.3 /Users/dominikhickman/i400-Folder/Reading-Project
 ✓ src/utils/pointCalculation.test.js (1 test) 6ms
   ✓ calculateLevel assigns the correct buddy level based on points 3ms
                                              
 Test Files  1 passed (1)
      Tests  1 passed (1)
   Start at  12:11:54   
   Duration  422ms (transform 31ms, setup 0ms, import 52ms, tests 6ms)
```
