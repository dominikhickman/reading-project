# Add Difficulty, Teacher Separation, & Student Creation

- [x] Create SQL migration for `difficulty` column and ask the user to run it
- [x] Update `AppContext.jsx` to limit `fetchClassData`, add `updateStudentDifficulty`, and `addStudent`
- [x] Update `TeacherDashboard.jsx` to include an "Add Student" form
- [x] Update `TeacherDashboard.jsx` to implement a functional Dropdown for difficulty
- [x] Update `BeeFlowerGame.jsx` to dynamically alter word count based on logged-in student's difficulty
